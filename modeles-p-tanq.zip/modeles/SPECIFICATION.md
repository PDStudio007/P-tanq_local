# Suite P-Tanq : spécification des fichiers d’échange (version 1)

Ce document décrit les fichiers échangés entre **P-Tanq Pro** (classement, base des joueurs), **Agenda** (calendrier et inscriptions) et **P-Tanq Local** (Agenda, Carreau et classement sur l’appareil de la ligue, sans réseau). Il s’adresse à ceux qui développent les exports et les imports de Pro et d’Agenda. Les modèles de chaque fichier sont fournis en CSV et en Excel, avec un paquet d’exemple complet.

## 1. Principes communs

**Les clés.** Elles sont identiques dans toutes les applications et ne changent jamais pendant une saison.

| Donnée | Clé | Exemple |
|---|---|---|
| Joueur | `Licence`, exactement comme dans Pro | `200245` |
| Ligue | `Code` officiel de la ligue | `LROP` |
| Association | `Code` de l’association | `LROP-001` |
| Concours | `Concours_id`, attribué par Pro ou par l’Agenda | `LROP-2026-12-06-1` |

Les 9 codes de ligue de la FRMP sont pré-chargés dans P-Tanq Local : LRCSP, LRTTHP, LRRSKP, LRFMP, LRMSP, LRDTP, LROP, LRSGLDP, LRBKP. Les noms complets se saisissent dans l’application (Saison › Ligues) ou arrivent par le fichier `ligues.csv`. Une ligue supplémentaire peut être ajoutée dans l’application.

**Le format.**
- CSV en UTF-8 (avec ou sans BOM), séparateur `;`, une ligne d’en-tête. Les fichiers Excel (.xlsx) sont acceptés, ainsi que les CSV en Windows-1252.
- Les noms de colonnes sont ceux des tableaux ci-dessous, sans accent, sans espace. L’ordre des colonnes est libre, les colonnes en plus sont ignorées et les colonnes facultatives peuvent manquer.
- Dates en `AAAA-MM-JJ` (`JJ/MM/AAAA` est accepté à l’import), heures en `HH:MM`, nombres décimaux avec un point ou une virgule.
- Une ligne dont la colonne `Numero` vaut `Ex.` est un exemple : elle est ignorée.
- P-Tanq Local reconnaît chaque fichier **par ses colonnes**, pas par son nom : un paquet peut contenir tout ou partie des fichiers, et un fichier peut être importé seul.

**Les paquets.** Un paquet est un .zip qui regroupe des fichiers CSV.
- **Paquet de saison** (Pro vers l’appareil de la ligue) : `saison-<LIGUE>-<SAISON>.zip`, en début de saison puis à chaque mise à jour.
- **Paquet de retour** (appareil vers Pro) : `retour-<LIGUE>-<AAAA-MM-JJ>.zip`, après un concours ou une période, dès qu’il y a du réseau.
- **Paquet d’un concours** (Carreau seul) : `p-tanq-pro-<concours>-<date>.zip`, avec les mêmes fichiers résultats, sanctions et inscriptions.

## 2. Qui produit quoi

| Fichier | Produit par | Lu par | Quand |
|---|---|---|---|
| `paquet.csv`, `ligues.csv`, `associations.csv`, `joueurs.csv` | Pro | P-Tanq Local | Début de saison, mises à jour |
| `types_epreuve.csv`, `bareme.csv` | Pro (ou le barème FRMP fourni) | P-Tanq Local | Début de saison, changement de règlement |
| `calendrier.csv` | Agenda ou Pro | P-Tanq Local | Début de saison, ajouts |
| `inscriptions.csv` | Agenda, associations, arbitres | P-Tanq Local | Avant chaque concours |
| `classement_depart.csv`, `sanctions_en_cours.csv` | Pro | P-Tanq Local | Reprise en cours de saison, mises à jour |
| `resultats.csv`, `sanctions.csv`, `inscriptions.csv`, `concours.csv` | P-Tanq Local, Carreau | Pro | Après chaque concours |
| `classement_ligue.csv`, `classement_associations.csv` | P-Tanq Local | Pro (contrôle) | Avec le retour |
| `sauvegarde.json` | P-Tanq Local, Carreau | P-Tanq Local, Carreau | Avec chaque paquet, et « Enregistrer dans Fichiers » |

Carreau seul (sans Agenda ni Pro) accepte en plus deux fichiers simples : le fichier des licences (`Nom;Prénom;Licence;Association;Ville`) et la liste d’équipes par noms (modèle d’inscription de Carreau, en Excel ou en Word).

## 3. Ce que Pro et l’Agenda doivent faire

**Export du paquet de saison, dans Pro, par ligue.**
1. `paquet.csv` avec `format = p-tanq-saison`, `version_format = 1`, la saison, ses dates, la ligue, la date d’export et le nombre de lignes de chaque fichier.
2. Les ligues, les associations et les joueurs de la ligue, avec le statut de leur licence.
3. Les types d’épreuve et le barème en vigueur (une ligne par type, stade et tranche).
4. Le calendrier de la ligue avec l’identifiant de chaque concours, ainsi que les inscriptions déjà connues.
5. Le classement acquis (points par licence) et les sanctions en cours.

**Import du paquet de retour, dans Pro.**
1. `resultats.csv` garde exactement le format actuel : l’import existant du Centre de données s’applique. `Nombre_engages` donne le total des équipes engagées : c’est lui qui fixe la tranche du barème.
2. `concours.csv` rattache chaque concours à son `Concours_id` et indique son état.
3. `sanctions.csv` : un import des sanctions est à créer dans Pro (une ligne par joueur sanctionné ; licence vide si le joueur n’a pas été reconnu).
4. `inscriptions.csv` : la liste finale des équipes (présentes, payées, abandons).
5. Les deux classements sont provisoires : ils servent à contrôler le calcul de Pro, qui reste le classement officiel.

**L’Agenda** exporte `calendrier.csv` et `inscriptions.csv` dans ces formats, avec les mêmes identifiants de concours que Pro.

## 4. Les fichiers, colonne par colonne


### 4.1 Paquet de saison (P-Tanq Pro vers l’appareil de la ligue)

**Fiche du paquet** (`paquet.csv`). Décrit le paquet : saison, ligue, date, nombre de lignes de chaque fichier (contrôle à l’import).

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Cle` | oui | texte | Nom de l’information. |
| `Valeur` | oui | texte | Valeur. format = p-tanq-saison ; dates en AAAA-MM-JJ ; repartition = equipe ou divise ; meilleurs_resultats = 0 pour tous. |

**Ligues** (`ligues.csv`). Liste des ligues de la fédération. Le code est la clé commune avec P-Tanq Pro.

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Code` | oui | code | Code officiel de la ligue (majuscules et chiffres, sans espace). Valeurs : `LRCSP`, `LRTTHP`, `LRRSKP`, `LRFMP`, `LRMSP`, `LRDTP`, `LROP`, `LRSGLDP`, `LRBKP`. |
| `Nom` |  | texte | Nom complet de la ligue. |
| `Actif` |  | oui/non | oui par défaut. Valeurs : `oui`, `non`. |

**Associations** (`associations.csv`). Associations (clubs) de la ligue. Le code est la clé commune avec P-Tanq Pro.

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Code` | oui | code | Code unique de l’association. |
| `Nom` | oui | texte | Nom de l’association, tel qu’il apparaît sur les feuilles. |
| `Ville` |  | texte | Ville. |
| `Ligue` | oui | code | Code de la ligue de rattachement. Valeurs : `LRCSP`, `LRTTHP`, `LRRSKP`, `LRFMP`, `LRMSP`, `LRDTP`, `LROP`, `LRSGLDP`, `LRBKP`. |
| `Statut` |  | liste | Active par défaut. Valeurs : `Active`, `Inactive`. |

**Joueurs licenciés** (`joueurs.csv`). Licenciés de la ligue pour la saison. Sert aux inscriptions, au contrôle des doublons et au classement.

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Licence` | oui | texte | Licence du joueur, exactement comme dans P-Tanq Pro (clé du joueur). |
| `Nom` | oui | texte | Nom de famille. |
| `Prenom` | oui | texte | Prénom. |
| `Association` | oui | code | Code de l’association du joueur (le nom est aussi accepté). |
| `Ville` |  | texte | Ville. |
| `Ligue` |  | code | Code de la ligue (par défaut, celle de l’association). Valeurs : `LRCSP`, `LRTTHP`, `LRRSKP`, `LRFMP`, `LRMSP`, `LRDTP`, `LROP`, `LRSGLDP`, `LRBKP`. |
| `Sexe` |  | liste | M ou F. Valeurs : `M`, `F`. |
| `Date_naissance` |  | date | AAAA-MM-JJ (JJ/MM/AAAA accepté). |
| `Categorie` |  | liste | Catégorie d’âge. Valeurs : `Senior`, `Junior`, `Vétéran`. |
| `Statut` |  | liste | Valide par défaut. Une licence suspendue empêche l’inscription. Valeurs : `Valide`, `Suspendue`, `Mutée`, `Non renouvelée`. |

**Types d’épreuve** (`types_epreuve.csv`). Catalogue des types de compétition et de leur mode de calcul des points (règlement FRMP, art. 23 à 25).

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Code` | oui | code | Code du type. Valeurs : `Concours`, `Concours2`, `Federale`, `Championnat`, `Super_League`, `Libre`, `Amical`. |
| `Libelle` | oui | texte | Libellé affiché. |
| `Famille` |  | liste | frmp, ligue ou libre. Valeurs : `frmp`, `ligue`, `libre`. |
| `Mode_points` | oui | liste | tranches (selon le nombre d’équipes engagées), fixe, aucun, libre (saisi à chaque concours). Valeurs : `tranches`, `fixe`, `aucun`, `libre`. |
| `Points_associations` |  | oui/non | L’épreuve donne-t-elle des points aux associations. Valeurs : `oui`, `non`. |

**Barème des points** (`bareme.csv`). Points de chaque joueur selon le type d’épreuve, le stade atteint et le nombre d’équipes engagées (FRMP, art. 25). Une ligne par stade et par tranche.

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Type` | oui | code | Code du type d’épreuve. Valeurs : `Concours`, `Concours2`, `Federale`, `Super_League`. |
| `Stade` | oui | liste | Stade atteint. Valeurs : `Vainqueur`, `Finaliste`, `Demi-finale`, `Quart`, `Huitieme`, `Sortie_Poule`, `Participation`. |
| `Min_equipes` |  | entier | Début de la tranche (vide pour un barème fixe). |
| `Max_equipes` |  | entier | Fin de la tranche (vide = sans limite, ou barème fixe). |
| `Points` | oui | nombre | Points attribués à chaque joueur de l’équipe. |
| `Valable_du` |  | date | Date d’entrée en vigueur (AAAA-MM-JJ). |

**Calendrier de la saison (Agenda)** (`calendrier.csv`). Concours programmés. Concours_id est la clé : les résultats reviennent vers Pro avec cet identifiant.

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Concours_id` | oui | texte | Identifiant du concours dans P-Tanq Pro (ex. LROP-2026-12-06-1). |
| `Date` | oui | date | AAAA-MM-JJ. |
| `Heure` |  | heure | HH:MM. |
| `Nom` | oui | texte | Nom du concours. |
| `Lieu` |  | texte | Boulodrome, ville. |
| `Ligue` | oui | code | Code de la ligue. Valeurs : `LRCSP`, `LRTTHP`, `LRRSKP`, `LRFMP`, `LRMSP`, `LRDTP`, `LROP`, `LRSGLDP`, `LRBKP`. |
| `Association` |  | code | Code de l’association organisatrice. |
| `Type` | oui | code | Type d’épreuve. Valeurs : `Concours`, `Federale`, `Championnat`, `Super_League`, `Libre`, `Amical`. |
| `Niveau` |  | liste | regional par défaut (même barème pour les trois niveaux). Valeurs : `regional`, `national`, `international`, `federal`. |
| `Formule` | oui | liste | Composition des équipes. Valeurs : `Triplette`, `Doublette`, `Tête-à-tête`. |
| `Categorie` |  | liste | Ouvert par défaut. Valeurs : `Ouvert`, `Seniors`, `Juniors`, `Féminines`, `Vétérans`, `Mixte`. |
| `Modele` |  | liste | Organisation dans Carreau (elim par défaut). Valeurs : `elim`, `poules`, `suisse`, `sl`, `classique`, `championnat`, `complet`, `melee`. |
| `Max_equipes` |  | entier | Nombre maximum d’équipes (vide = sans limite). |
| `Statut` |  | liste | Programme par défaut. Valeurs : `Programme`, `Annule`. |

**Classement de départ** (`classement_depart.csv`). Points déjà acquis dans la saison avant le paquet, par joueur (reprise en cours de saison).

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Licence` | oui | texte | Licence du joueur, exactement comme dans P-Tanq Pro (clé du joueur). |
| `Nom` |  | texte |  |
| `Prenom` |  | texte |  |
| `Association` |  | code |  |
| `Points` | oui | nombre | Total des points déjà acquis. |
| `Concours` |  | entier | Nombre de concours déjà comptés. |

**Sanctions en cours** (`sanctions_en_cours.csv`). Suspensions et exclusions en cours : un joueur suspendu à la date d’un concours ne peut pas s’y inscrire.

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Licence` | oui | texte | Licence du joueur, exactement comme dans P-Tanq Pro (clé du joueur). |
| `Nom` |  | texte |  |
| `Prenom` |  | texte |  |
| `Type` | oui | texte | Suspension, Exclusion ou Avertissement (seules suspensions et exclusions bloquent). |
| `Debut` |  | date | AAAA-MM-JJ. |
| `Fin` |  | date | AAAA-MM-JJ (vide = sans fin). |
| `Motif` |  | texte |  |

### 4.2 Inscriptions (Agenda, associations et arbitres ; aussi au retour)

**Inscriptions (équipes)** (`inscriptions.csv`). Une ligne par équipe. Sert dans les deux sens : inscriptions préalables (Pro, Agenda, associations) et liste finale (retour vers Pro). Les arbitres remplissent ce même modèle.

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Concours_id` | oui | texte | Identifiant du concours (calendrier). |
| `Date` |  | date | Date du concours (contrôle). |
| `Concours` |  | texte | Nom du concours (contrôle). |
| `Numero` |  | entier | Numéro d’équipe (attribué à l’import si vide). |
| `Association` |  | code | Code de l’association de l’équipe (par défaut, celle du chef). |
| `Licence_1` | oui | texte | Licence du chef d’équipe. |
| `Nom_1` |  | texte | Nom (utilisé si la licence est inconnue). |
| `Prenom_1` |  | texte | Prénom. |
| `Licence_2` |  | texte | Licence du 2e joueur. |
| `Nom_2` |  | texte |  |
| `Prenom_2` |  | texte |  |
| `Licence_3` |  | texte | Licence du 3e joueur (triplette). |
| `Nom_3` |  | texte |  |
| `Prenom_3` |  | texte |  |
| `Observations` |  | texte | Jeunes, Femmes, Hors-Ligue, International ou texte libre. |
| `Presente` |  | oui/non | Retour vers Pro seulement. Valeurs : `oui`, `non`. |
| `Payee` |  | oui/non | Retour vers Pro seulement. Valeurs : `oui`, ``. |
| `Absente_en_cours` |  | oui/non | Retour vers Pro seulement. Valeurs : `oui`, ``. |

### 4.3 Paquet de retour (appareil vers P-Tanq Pro)

**Résultats (format actuel de P-Tanq Pro)** (`resultats.csv`). Stade atteint par chaque équipe ayant joué. Format inchangé, importé dans le Centre de données de Pro. Une ligne par équipe et par prix.

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Ligue` | oui | code | Code de la ligue. |
| `Date` | oui | date |  |
| `Epreuve` | oui | code | Concours (1er prix), Concours2 (2e prix), Federale, Championnat, Super_League, Libre. |
| `Concours` | oui | texte | Nom du concours. |
| `Format` | oui | liste | Valeurs : `Triplette`, `Doublette`, `Tête-à-tête`. |
| `Nombre_equipes` | oui | entier | Équipes du prix (chemin A ou B). |
| `Club_organisateur` |  | texte |  |
| `Numero` | oui | entier | Numéro de l’équipe. |
| `Stade` | oui | liste | Valeurs : `Vainqueur`, `Finaliste`, `Demi-finale`, `Quart`, `Huitieme`, `Sortie_Poule`, `Participation`. |
| `Licence_1` | oui | texte |  |
| `Nom_1` |  | texte |  |
| `Prenom_1` |  | texte |  |
| `Licence_2` |  | texte |  |
| `Nom_2` |  | texte |  |
| `Prenom_2` |  | texte |  |
| `Licence_3` |  | texte |  |
| `Nom_3` |  | texte |  |
| `Prenom_3` |  | texte |  |
| `Club` |  | texte | Association de l’équipe. |
| `Nombre_engages` | oui | entier | Total des équipes engagées dans le concours (sert à choisir la tranche du barème). |
| `Niveau` |  | liste | Valeurs : `regional`, `national`, `international`. |
| `Points` |  | nombre | Rempli seulement pour Libre. |

**Sanctions prononcées** (`sanctions.csv`). Cartons et décisions des arbitres pendant les concours.

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Date` | oui | date |  |
| `Concours` | oui | texte |  |
| `Licence` |  | texte | Vide si le joueur n’est pas reconnu. |
| `Joueur` | oui | texte |  |
| `Carton` |  | liste | Valeurs : `blanc`, `jaune`, `orange`, `rouge`. |
| `Decision` | oui | texte | Code de la décision de l’arbitre. |
| `Nature` |  | texte | Libellé de la décision. |
| `Partie` |  | texte |  |
| `Heure` |  | heure |  |
| `Arbitre` |  | texte |  |
| `Motif` |  | texte |  |

**État des concours** (`concours.csv`). Relie chaque concours joué à son identifiant Pro, avec son état et son vainqueur.

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Concours_id` | oui | texte | Identifiant du calendrier. |
| `Date` | oui | date |  |
| `Ligue` | oui | code |  |
| `Concours` | oui | texte |  |
| `Association` |  | code | Association organisatrice. |
| `Type` | oui | code |  |
| `Niveau` |  | liste |  |
| `Formule` | oui | liste |  |
| `Categorie` |  | liste |  |
| `Nombre_equipes` | oui | entier |  |
| `Statut` | oui | liste | Valeurs : `Inscriptions`, `En_cours`, `Termine`. |
| `Vainqueur` |  | texte | Chef de l’équipe gagnante. |
| `Exporte_le` |  | date | Date du précédent export. |

**Classement provisoire des joueurs** (`classement_ligue.csv`). Calculé sur l’appareil, pour contrôle : Pro reste le classement officiel.

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Rang` | oui | entier |  |
| `Licence` | oui | texte |  |
| `Nom` | oui | texte |  |
| `Prenom` |  | texte |  |
| `Association` |  | code |  |
| `Points_depart` | oui | nombre |  |
| `Points_saison` | oui | nombre |  |
| `Points_total` | oui | nombre |  |
| `Nombre_concours` | oui | entier |  |

**Classement provisoire des associations** (`classement_associations.csv`). Points des associations : concours régionaux de leur ligue et compétitions fédérales (FRMP, art. 25).

| Colonne | Obl. | Type | Description |
|---|---|---|---|
| `Rang` | oui | entier |  |
| `Code` | oui | code |  |
| `Association` | oui | texte |  |
| `Ligue` |  | code |  |
| `Points` | oui | nombre |  |
| `Nombre_concours` | oui | entier |  |


## 5. Le barème de la FRMP (extrait des Règlements généraux, articles 19, 23, 24 et 25)

**Les formes de concours.**
- **Formules (composition des équipes)** : triplette, doublette, tête-à-tête. Le tir de précision est une épreuve individuelle des championnats fédéraux.
- **Catégories** : seniors, juniors, féminines (championnats fédéraux, article 23). Dans les fichiers : `Ouvert`, `Seniors`, `Juniors`, `Féminines`, `Vétérans`, `Mixte`.
- **Niveaux** d’un concours : régional, national, international. Ils ont le même barème. La colonne « C. Fédéral » du tableau correspond aux compétitions fédérales.
- **Organisation sur le terrain** (Carreau) : élimination directe (1er prix pour le chemin A, 2e prix pour le chemin B), poules puis phase finale, système suisse, Super-League et L’Open, championnat (tous contre tous), mêlée.

**Les types de compétition** (`types_epreuve.csv`).

| Code | Compétition | Mode de points | Points des associations |
|---|---|---|---|
| `Concours` | Concours régional, 1er prix (régional, national, international) | Par tranches | Oui, dans sa ligue |
| `Concours2` | Concours régional, 2e prix | Par tranches | Oui, dans sa ligue |
| `Federale` | Compétition fédérale : championnats triplettes, doublettes, tête-à-tête, seniors, juniors, féminines, tir de précision, Coupe du Trône (art. 23) | Fixe | Oui |
| `Championnat` | Championnat du Maroc | Aucun point (art. 25) | Non |
| `Super_League` | Super-League (épreuve de ligue, absente du règlement) | Fixe, barème de la ligue | Non |
| `Libre` | Épreuves de l’article 24 (Trophée inter-ligues, Trophée des As, Grand Festival Panache, Trophée triplettes mixtes…) et autres : modalités fixées par la commission | Saisi pour chaque concours | Non |
| `Amical` | Concours autorisé, hors classement | Aucun point | Non |

**Les points de chaque joueur** (`bareme.csv`). Les points dépendent du type, du prix et du nombre d’équipes engagées. Ils sont attribués aux associations et, dans les mêmes conditions, individuellement à chaque joueur de l’équipe, même s’il change de partenaires ou d’association (article 25).

1er prix et compétition fédérale :

| Stade | Compétition fédérale | 1 à 64 équipes | 65 à 128 | 129 à 256 | 257 et plus |
|---|---|---|---|---|---|
| Vainqueur | 12 | 6 | 7 | 8 | 10 |
| Finaliste | 10 | 4 | 5 | 6 | 8 |
| ½ finale | 8 | 2 | 3 | 4 | 6 |
| ¼ de finale | 4 | 1 | 2 | 3 | 4 |

2e prix (pas de 2e prix en compétition fédérale) :

| Stade | 1 à 127 équipes | 128 à 256 | 257 et plus |
|---|---|---|---|
| Vainqueur | 2 | 3 | 4 |
| Finaliste | 1 | 2 | 3 |

Aucun point n’est prévu pour les huitièmes, la sortie de poule ou la participation. Un championnat du Maroc ne donne aucun point.

**Les points des associations.** Une association ne marque que dans les concours régionaux de sa propre ligue et dans les compétitions fédérales. Chaque équipe lui apporte les points de son stade, une seule fois par équipe.

**La répartition des prix en argent** (article 19, `repartition_prix.csv`). Le prix global est d’au moins 12 000 Dh : deux tiers vont au 1er prix et un tiers au 2e prix.

| Stade | 1er prix | 2e prix |
|---|---|---|
| Champion | 30 % | 40 % |
| Sous-champion | 20 % | 20 % |
| ½ finale | 20 % | 20 % |
| ¼ de finale | 20 % | 20 % |
| 1/8 de finale | 10 % | — |

**Les choix faits là où le texte n’est pas précis.** Ils sont à confirmer par la FRMP.
- Le tableau dit « moins de 64 » puis « 65 à 128 » : 64 équipes sont classées dans la première tranche (1 à 64).
- Au 2e prix, il dit « moins de 128 » puis « 128 à 256 » : 128 équipes sont classées dans la deuxième tranche (128 à 256).
- La tranche se choisit sur le **total des équipes engagées** dans le concours (colonne `Nombre_engages`), et non sur l’effectif de chaque prix.
- Le tableau parle de triplettes : les mêmes tranches s’appliquent aux doublettes et aux tête-à-tête, en comptant les équipes.
- Le texte ne parle pas d’« assiette » : par défaut, chaque joueur reçoit les points de son équipe et tous les résultats de la saison comptent. Deux réglages existent dans l’application et dans `paquet.csv` : `repartition` (`equipe` ou `divise`) et `meilleurs_resultats` (0 pour tous, sinon le nombre de meilleurs résultats retenus).
- La source est un extrait des Règlements généraux, analysé le 2 novembre 2026 : sa version est à confirmer.



## 6. Modèles fournis

- `pro-vers-appareil/` : un modèle CSV et un modèle Excel pour chaque fichier du paquet de saison. Les modèles Excel ont un onglet « Colonnes » qui décrit chaque colonne, et des listes déroulantes pour les valeurs permises.
- `appareil-vers-pro/` : les fichiers du paquet de retour, avec une ligne d’exemple.
- `arbitres-et-associations/` : le modèle d’inscription par licence (Excel avec mode d’emploi, Word, CSV) et le fichier simple des licences pour Carreau.
- `bareme-frmp/` : le barème extrait du règlement (`bareme.csv`, `types_epreuve.csv`, `repartition_prix.csv` et un classeur lisible).
- `exemples/` : un paquet de saison complet et fictif pour la ligue LROP (200 joueurs, 8 associations, 5 concours, 24 équipes inscrites), importable tel quel dans P-Tanq Local, et un paquet de retour d’exemple.
- `formats.json` : la même description, lisible par un programme (colonnes, types, valeurs permises).
